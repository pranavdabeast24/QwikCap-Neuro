QuickCap (CV) — synthetic PACE practice kit
Property of Capitolinus Ventures

ENTIRELY FICTIONAL SOFTWARE TEST DATA. NOT CLINICAL CASES.

There are two fictional records, with nine source PDFs each:
  text/forms: SYNTH-PACE-0001 — selectable PDF text
  scan/forms: SYNTH-PACE-0002 — raster-only scans, different answers
Each record has 26 original pages. QuickCap adds an operator ID cover.

The fixture exercises all codebook branches for software coverage, so its answers
are not intended to describe a coherent patient. The 512 export columns retain
the supplied template order. Six calculated/display/attachment reference items
are represented without inventing export columns or an unavailable image.
Checkboxes use explicit printed coded values, not recognized checkbox marks.
Dates and codes must be reviewed. Completion values are Unverified (1).

In QuickCap:
1. Load synthetic-pace-extraction-type.json using Load type.
2. Combine the nine PDFs from ONE case, in filename order 01 through 09.
3. Enter the matching study ID above and confirm the files belong together.
4. Review answers against the source. Compare with answer-key.csv or .json.
5. Correct OCR errors, confirm each field, enter a reviewer name and approve.
6. Use categories as columns, inspect all 512 assignments, confirm mapping.
7. Export XLSX. It is a reviewed staging sheet; confirm the target REDCap
   project's requirements, longitudinal/repeating structure and import preview.

The extraction type contains field rules and masks, not extracted answers.
The answer key is for independent evaluation, not app input.
This kit does not contain the separately supplied train or held-out test set.
OCR accuracy and final app-export results are reported separately.
